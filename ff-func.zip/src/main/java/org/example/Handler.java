package org.example;



import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;

import java.util.function.Function;

class Request {
    public String message;
    public int number;
}

public class Handler implements Function<Request, String> {

    @Override
    public String apply(Request r) {
        String bucketName = "your_bucket_name";
        String key = "your_object_key";
        String localFileName = "local_file_name";

        S3Client s3 = S3Client.builder().credentialsProvider(DefaultCredentialsProvider.create()).build();

        GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(key).build();

        ResponseInputStream<GetObjectResponse> s3Object = s3.getObject(getObjectRequest);
        return String.format("Message is %s, number is %d", r.message, r.number) + " | isSuccessful: " + s3Object.response().sdkHttpResponse().isSuccessful();
    }
}